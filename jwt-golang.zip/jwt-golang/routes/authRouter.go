package routes

import (
	"jwt-golang/controllers"

	"github.com/gofiber/fiber/v2"
)

// AuthRouter defines the routes for the authentication endpoints
func AuthRouter(app *fiber.App) {
	app.Post("/login", controllers.LoginController)
	app.Get("")
}
