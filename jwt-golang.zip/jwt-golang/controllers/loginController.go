// routes/auth.go

package controllers

import (
	"jwt-golang/models"

	"jwt-golang/helpers"

	"github.com/gofiber/fiber/v2"
)

// LoginHandler handles the API login request
func LoginController(c *fiber.Ctx) error {
	var loginRequest models.Login
	if err := c.BodyParser(&loginRequest); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"message": "Invalid request"})
	}

	// Your authentication logic here
	// For example, validate the username and password from the login request

	token, err := helpers.GenerateJWT()
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"message": "Failed to generate token"})
	}

	// Return the JWT token in the response
	return c.JSON(fiber.Map{"token": token})
}
