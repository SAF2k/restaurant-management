package controllers

import (
	"jwt-golang/models"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v4"
)

var jwtKey = []byte("my_secret_key")

// HomeHandler handles the /home endpoint
func HomeController(c *fiber.Ctx) error {
	bearerToken := c.Get("Authorization")
	if bearerToken == "" {

		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"message": "missingF Authorization header"})
	}

	// Extract token from Authorization header
	tokenParts := strings.Split(bearerToken, " ")
	if len(tokenParts) != 2 || tokenParts[0] != "Bearer" {

		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"message": "invalid Authorization header format"})
	}
	reqToken := tokenParts[1]

	// Parse JWT token
	claims := models.Claims{}
	tkn, err := jwt.ParseWithClaims(reqToken, claims, func(token *jwt.Token) (interface{}, error) {
		return jwtKey, nil
	})
	if err != nil {
		if err == jwt.ErrSignatureInvalid {

			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"message": "unauthorized"})
		}

		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"message": "failed to parse token", "error": err.Error()})
	}
	if !tkn.Valid {

		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"message": "unauthorized"})
	}

	// If the token is valid, return the resource data
	c.Status(fiber.StatusOK).JSON(fiber.Map{"data": "resource data"})
	return c.JSON(fiber.Map{"message": "Welcome to the home page!"})
}
