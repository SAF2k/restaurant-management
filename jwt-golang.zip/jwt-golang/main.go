package main

import (
	"jwt-golang/helpers"

	"jwt-golang/database"

	"github.com/gofiber/fiber"
)

// var jwtKey = []byte("my_secret_key")

// type Claims struct {
// 	Username string `json:"username"`
// 	jwt.RegisteredClaims
// }

// func main() {
// 	app := fiber.New()

// 	app.Post("/login", func(c *fiber.Ctx) {
// 		token, err := generateJWT() // Generate JWT token
// 		if err != nil {
// 			c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "Failed to generate JWT"})
// 			return
// 		}

// 		// Return the generated JWT token
// 		c.Status(fiber.StatusOK).JSON(fiber.Map{"token": token})
// 	})

// 	app.Get("/resource", func(c *fiber.Ctx) {
// 		bearerToken := c.Get("Authorization")
// 		if bearerToken == "" {
// 			c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"message": "missing Authorization header"})
// 			return
// 		}

// 		// Extract token from Authorization header
// 		tokenParts := strings.Split(bearerToken, " ")
// 		if len(tokenParts) != 2 || tokenParts[0] != "Bearer" {
// 			c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"message": "invalid Authorization header format"})
// 			return
// 		}
// 		reqToken := tokenParts[1]

// 		// Parse JWT token
// 		claims := &Claims{}
// 		tkn, err := jwt.ParseWithClaims(reqToken, claims, func(token *jwt.Token) (interface{}, error) {
// 			return jwtKey, nil
// 		})
// 		if err != nil {
// 			if err == jwt.ErrSignatureInvalid {
// 				c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"message": "unauthorized"})
// 				return
// 			}
// 			c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"message": "failed to parse token", "error": err.Error()})
// 			return
// 		}
// 		if !tkn.Valid {
// 			c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"message": "unauthorized"})
// 			return
// 		}

// 		// If the token is valid, return the resource data
// 		c.Status(fiber.StatusOK).JSON(fiber.Map{"data": "resource data"})
// 	})

// 	app.Listen(":8081") // Listen and serve on 0.0.0.0:8081
// }

// func generateJWT() (string, error) {
// 	expirationTime := time.Now().Add(5 * time.Minute)
// 	claims := &Claims{
// 		Username: "username",
// 		RegisteredClaims: jwt.RegisteredClaims{
// 			ExpiresAt: jwt.NewNumericDate(expirationTime),
// 		},
// 	}

// 	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)

// 	return token.SignedString(jwtKey)

// }

func main() {
	helpers.LoadConfig(".env")
	database.Connect()

	app := fiber.New()

	// Logger middleware
	app.Use(func(c *fiber.Ctx) error {
		println("Request:", c.Method(), c.Path())
		return c.Next()
	})

	app.Post("/login", routes.LoginHandler)

	// Routes for authentication
	app.Post("/login", routes.LoginHandler) // Register the login route handler

	// Middleware for authentication
	app.Use(func(c *fiber.Ctx) error {
		// Your authentication logic here
		return c.Next()
	})

	// Routes for users
	routes.UserRoutes(app)

	// Start the Fiber server
	app.Listen(":" + helpers.AppConfig.PORT)
}
